package main;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.printer.XmlPrinter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class AST {

    public static void main(String[] args) {
        try {
            // Parse a Java file at the given path
            ParseResult<CompilationUnit> parseResult = new JavaParser().parse(Paths.get("C:/Users/IanF0/Desktop/College Stuffs/Semester 6/Principles of Programming Languages/ASTTest.java"));

            if (parseResult.isSuccessful() && parseResult.getResult().isPresent()) {
                CompilationUnit cu = parseResult.getResult().get();
                
                // Convert the AST to XML
                XmlPrinter printer = new XmlPrinter(true); // Pass true to print comments
                String xml = printer.output(cu);

                // Creates XML file with given name and path
                Path xmlPath = Paths.get("C:/Users/IanF0/Desktop/College Stuffs/Semester 6/Principles of Programming Languages/AST.xml");

                // Write the XML string to the file
                Files.write(xmlPath, xml.getBytes(), StandardOpenOption.CREATE);

                System.out.println("AST written to XML file.");
            } else {
                System.out.println("Parsing was not successful.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
